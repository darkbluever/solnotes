# solnotes
This is my blog records my tracks.
